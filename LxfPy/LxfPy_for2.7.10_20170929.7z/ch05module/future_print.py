#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
 Author:      fyso@163.com
 DateTime:    2017-08-29 22:41:20
 Description: Description
"""
from __future__ import print_function
__author__ = 'FengYang'


print('-----------2 str和unicode -----------')
# Python 2.6可以通过 import __future__ 来将print从语言语法中移除，让你可以使用函数的形式。例如：
mv = [1,2]
print('# of entries')
print("aaa")
# 2.7已经直接支持这么干了！
# print 'aaa'


﻿# -*- coding: utf-8 -*-
"""
Created on Wed Nov 09 14:10:01 2016
@author: Administrator
created by CMCC.fengyang
fyso@163.com
"""

print 'hello, world!'
print 'Git-dev'
x = 3
print x

#别忘了，2016年11月9日，才最终搞定了git的文字版使用！之前在黑暗中摸索了很久！----20170826
